<?php require_once('./php_Action/core.php');
require_once('Includes/header.php'); ?>
	<!----------Featured Categories--------------->
	<div class="categories">
		<div class="small-container">
			<div class="row">
			<div class="col-3">
				<img src="Images/category-1.jpg">
			</div>
			<div class="col-3">
				<img src="Images/category-2.jpg">
			</div>
			<div class="col-3">
				<img src="Images/category-3.jpg">
			</div>
		</div>
		
		</div>
		
	</div>
	
	<!-----------Featured Products------------->
	<div class="small-container">
	<h2 class="title">Featured Products</h2>
		<div class="row">
			<div class="col-4">
				<img src="Images/category-1.jpg">
				<h4>item eke nama</h4>
				<div class="rating">
					<i class="fa fa-star" ></i>
					<i class="fa fa-star" ></i>
					<i class="fa fa-star" ></i>
					<i class="fa fa-star" ></i>
					<i class="fa fa-star-o" ></i>
				 </div>
				<p>Rs.1500.00</p>
			</div>
			<div class="col-4">
				<img src="Images/category-1.jpg">
				<h4>item eke nama</h4>
				<div class="rating">
					<i class="fa fa-star" ></i>
					<i class="fa fa-star" ></i>
					<i class="fa fa-star" ></i>
					<i class="fa fa-star" ></i>
					<i class="fa fa-star-o" ></i>
				 </div>
				<p>Rs.1500.00</p>
			</div>
			<div class="col-4">
				<img src="Images/category-1.jpg">
				<h4>item eke nama</h4>
				<div class="rating">
					<i class="fa fa-star" ></i>
					<i class="fa fa-star" ></i>
					<i class="fa fa-star" ></i>
					<i class="fa fa-star" ></i>
					<i class="fa fa-star-o" ></i>
				 </div>
				<p>Rs.1500.00</p>
			</div>
			<div class="col-4">
				<img src="Images/category-1.jpg">
				<h4>item eke nama</h4>
				<div class="rating">
					<i class="fa fa-star" ></i>
					<i class="fa fa-star" ></i>
					<i class="fa fa-star" ></i>
					<i class="fa fa-star" ></i>
					<i class="fa fa-star-o" ></i>
				 </div>
				<p>Rs.1500.00</p>
			</div>
		</div>
		<h2 class="title">Latest Products</h2>
		<div class="row">
			<div class="col-4">
				<img src="Images/category-1.jpg">
				<h4>item eke nama</h4>
				<div class="rating">
					<i class="fa fa-star" ></i>
					<i class="fa fa-star" ></i>
					<i class="fa fa-star" ></i>
					<i class="fa fa-star" ></i>
					<i class="fa fa-star-o" ></i>
				 </div>
				<p>Rs.1500.00</p>
			</div>
			<div class="col-4">
				<img src="Images/category-1.jpg">
				<h4>item eke nama</h4>
				<div class="rating">
					<i class="fa fa-star" ></i>
					<i class="fa fa-star" ></i>
					<i class="fa fa-star" ></i>
					<i class="fa fa-star" ></i>
					<i class="fa fa-star-o" ></i>
				 </div>
				<p>Rs.1500.00</p>
			</div>
			<div class="col-4">
				<img src="Images/category-1.jpg">
				<h4>item eke nama</h4>
				<div class="rating">
					<i class="fa fa-star" ></i>
					<i class="fa fa-star" ></i>
					<i class="fa fa-star" ></i>
					<i class="fa fa-star" ></i>
					<i class="fa fa-star-o" ></i>
				 </div>
				<p>Rs.1500.00</p>
			</div>
			<div class="col-4">
				<img src="Images/category-1.jpg">
				<h4>item eke nama</h4>
				<div class="rating">
					<i class="fa fa-star" ></i>
					<i class="fa fa-star" ></i>
					<i class="fa fa-star" ></i>
					<i class="fa fa-star" ></i>
					<i class="fa fa-star-o" ></i>
				 </div>
				<p>Rs.1500.00</p>
			</div>
		</div>
		<div class="row">
			<div class="col-4">
				<img src="Images/category-1.jpg">
				<h4>item eke nama</h4>
				<div class="rating">
					<i class="fa fa-star" ></i>
					<i class="fa fa-star" ></i>
					<i class="fa fa-star" ></i>
					<i class="fa fa-star" ></i>
					<i class="fa fa-star-o" ></i>
				 </div>
				<p>Rs.1500.00</p>
			</div>
			<div class="col-4">
				<img src="Images/category-1.jpg">
				<h4>item eke nama</h4>
				<div class="rating">
					<i class="fa fa-star" ></i>
					<i class="fa fa-star" ></i>
					<i class="fa fa-star" ></i>
					<i class="fa fa-star" ></i>
					<i class="fa fa-star-o" ></i>
				 </div>
				<p>Rs.1500.00</p>
			</div>
			<div class="col-4">
				<img src="Images/category-1.jpg">
				<h4>item eke nama</h4>
				<div class="rating">
					<i class="fa fa-star" ></i>
					<i class="fa fa-star" ></i>
					<i class="fa fa-star" ></i>
					<i class="fa fa-star" ></i>
					<i class="fa fa-star-o" ></i>
				 </div>
				<p>Rs.1500.00</p>
			</div>
			<div class="col-4">
				<img src="Images/category-1.jpg">
				<h4>item eke nama</h4>
				<div class="rating">
					<i class="fa fa-star" ></i>
					<i class="fa fa-star" ></i>
					<i class="fa fa-star" ></i>
					<i class="fa fa-star" ></i>
					<i class="fa fa-star-o" ></i>
				 </div>
				<p>Rs.1500.00</p>
			</div>
		</div>
	</div>
	
	
	<!------------offer------------------->
	
	<div class="offer">
		<div class="small-container">
			<div class="row">
				<div class="col-2">
					<img src="Images/exclusive.png" class="offer-img">
				</div>
				<div class="col-2">
					<p>Exclusively available on ShopUZ</p>
					<h1>Samrt Band 4</h1>
					<small>samrt band eka gana</small>
					<br></br>
					<a href="" class="btn">Buy Now &#8594;</a>
				</div>
			</div>
		</div>
	</div>
	
	<!------------Testimonial------------->
	<div class="testimonial">
		<div class="small-container">
			<div class="row">
				<div class="col-3">
					<i class="fa fa-quote-left" ></i>
					<p>Im looking to see how this video can be imroved. It is for online English classes and would like to make it more professional. Is this possible? </p>
					<div class="rating">
					<i class="fa fa-star" ></i>
					<i class="fa fa-star" ></i>
					<i class="fa fa-star" ></i>
					<i class="fa fa-star" ></i>
					<i class="fa fa-star-o" ></i>
				    </div>
					<img src="Images/user-1.png">
					<h3>Tilan Liyanage</h3>
				</div>
				<div class="col-3">
					<i class="fa fa-quote-left" ></i>
					<p>Im looking to see how this video can be imroved. It is for online English classes and would like to make it more professional. Is this possible? </p>
					<div class="rating">
					<i class="fa fa-star" ></i>
					<i class="fa fa-star" ></i>
					<i class="fa fa-star" ></i>
					<i class="fa fa-star" ></i>
					<i class="fa fa-star-o" ></i>
				    </div>
					<img src="Images/user-2.png">
					<h3>Tilan Liyanage</h3>
				</div>
				<div class="col-3">
					<i class="fa fa-quote-left" ></i>
					<p>Im looking to see how this video can be imroved. It is for online English classes and would like to make it more professional. Is this possible? </p>
					<div class="rating">
					<i class="fa fa-star" ></i>
					<i class="fa fa-star" ></i>
					<i class="fa fa-star" ></i>
					<i class="fa fa-star" ></i>
					<i class="fa fa-star-o" ></i>
				    </div>
					<img src="Images/user-3.png">
					<h3>Tilan Liyanage</h3>
				</div>
			</div>
		</div>
	</div>
	
	
	<!--------------brands----------->
	<div class="brands">
		<div class="small-container">
			<div class="row">
				<div class="col-5">
					<img src="Images/logo-oppo.png">
				</div>
				<div class="col-5">
					<img src="Images/logo-philips.png">
				</div>
				<div class="col-5">
					<img src="Images/logo-rolex.png">
				</div>
				<div class="col-5">
					<img src="Images/logo-paypal.png">
				</div>
				<div class="col-5">
					<img src="Images/logo-coca-cola.png">
				</div>
			</div>
		 </div>
	</div>
	
<?php require_once('Includes/footer.php'); ?>