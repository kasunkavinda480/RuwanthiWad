<?php require_once('./php_Action/core.php');
if (isset($_POST['SubMintBtn'])) {
	if (isset($_SESSION['shopping_cart'])) {

		$arrid =  array_column($_SESSION['shopping_cart'], 'itm_id');

		if (in_array($_GET['idTxt'], $arrid)) {
			$out = "All Ready In the array";
		} else {
			$conut = count($_SESSION['shopping_cart']);
			$itm_arr  = array(
				'itm_id' => $_GET['idTxt'],
				'itm_image' => $_POST['ImageTxt'],
				'imt_name' => $_POST['nameTxt'],
				'itm_price' => $_POST['PriceTxt'],
				'itm_qty' => $_POST['QtyTxt']

			);
			$_SESSION['shopping_cart'][$conut] = $itm_arr;
			$out = 'Add To cart';
		}
	} else {
		$itm_arr  = array(
			'itm_id' => $_GET['idTxt'],
			'itm_image' => $_POST['ImageTxt'],
			'imt_name' => $_POST['nameTxt'],
			'itm_price' => $_POST['PriceTxt'],
			'itm_qty' => $_POST['QtyTxt']

		);
		$_SESSION['shopping_cart'][0] = $itm_arr;
		$out = 'Add To cart';
	}

	echo $out;
}

require_once('Includes/header.php'); ?>


<!-----------single product details------------->
<div class="small-container single-product">
	<div class="row">
		<div class="col-2" id="mainAddImage">
			<img src="Images/gallery-1.jpg">
		</div>
		<div class="col" style="padding-left: 10px;">
			<p>Home / T-Shirt</p>
			<h1 id="AddTitleTXt">Red Printed T-Shirt By HRX</h1>
			<h4 id="priceTXt">Rs 1500.00</h4>
			<select>
				<option>Select Size</option>
				<option>XXL</option>
				<option>XL</option>
				<option>Large</option>
				<option>Medium</option>
				<option>Small</option>
			</select>
			<div id="mainfrmcart">

			</div>

		</div>
	</div>
	<br><br>
	<hr>
	<div class="row">

		<div class="col-2 maindesclas">
			<h3>Product Details</h3>
			<p id="desctiptionTxt">mona hari product eka gana</p>
		</div>

	</div>
	
	<hr>
	<br><br>
</div>



<div class="small-container" id="loadrelatedProDiv">

</div>
<script src="custom/js/viewad.js"></script>
<input type="hidden" readonly id="aid" value="<?php if (isset($_GET['aid'])) {
													echo ($_GET['aid']);
												} else {
													echo "0";
												}
												?>">
<?php require_once('Includes/footer.php'); ?>