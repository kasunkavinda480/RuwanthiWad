<?php require_once('./php_Action/core.php');
if (isloggin() == false) {
    header('location: register.php');
}
require_once('Includes/header.php'); ?>
<div class="small-container cart-page">
    <table>
        <tr>
            <th>Order ID</th>
            <th>Address</th>
            <th>Net Amount</th>
            <th>Date</th>
            <th>Order State</th>
        </tr>
        <?php 
            $userID = $_SESSION['userId'];
            $query = "SELECT * FROM `order` WHERE Users_id = $userID";
            $result = $connect->query($query);
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_array()) {
                    if($row['state'] == 0){
                        $state = 'Pending';
                    }else{
                        $state = 'Done';
                    }
                    ?>
                    <tr>
                        <td><?php echo($row['oid']); ?></td>
                        <td><?php echo($row['Address']); ?></td>
                        <td><?php echo($row['NetAmount']); ?></td>
                        <td><?php echo($row['odate']); ?></td>
                        <td><?php echo($state); ?></td>
                    </tr>
<?php
                }
            }
        ?>
    </table>
</div>

<?php require_once('Includes/footer.php'); ?>