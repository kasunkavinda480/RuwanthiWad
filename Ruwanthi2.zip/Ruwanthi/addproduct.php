<?php
//addproduct.php
require_once('./php_Action/core.php');
//if(isloggin() == false){
//    header('location: register.php');
//}
require_once('Includes/header.php'); ?>
<script src="custom/js/addproduct.js"></script>
<form name="postAdForm" id="postAdForm" action="#" method="post" enctype="multipart/form-data">
    <div class="container form">

        <hr>
        <label for="Title" style="padding-top:10px;"><b>Title :</b></label>
        <input type="text" class="form-control" placeholder="Enter Title" name="titleTxt" id="titleTxt" required>
        <br>
        <label for="Phone" style="padding-top:10px;"><b>Phone :</b></label>
        <input type="number" class="form-control" name="phoneTxt" id="phoneTxt" value="0<?php echo ($_SESSION['phone']); ?>" required>
        <br>
        <label for="Category" style="padding-top:10px;"><b>Category :</b></label>
        <select id="categoryTxt" name="categoryTxt" class="form-control">
            <?php
            $query1 = "SELECT * FROM `category` WHERE `category_type` IN (SELECT DISTINCT(`category_type`) AS 'category_type' FROM `category` ORDER BY `category_type`)";
            $result = $connect->query($query1);
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_array()) {
            ?>
                    <option value="<?php echo $row['id']; ?>"><?php echo $row['category_type']; ?></option>

            <?php
                }
            }
            ?>
        </select>
        <br>
        <div id="Location" class="dropdown-check-list" tabindex="100" style="padding-top:10px;">
            <span class="anchor"><b>Location (ස්ථානය):</b></span>
            <ul class="items">
                <?php
                $query1 = "SELECT * FROM `locations` WHERE `Location` IN (SELECT DISTINCT(`Location`) FROM locations ORDER BY Location)";
                $result = $connect->query($query1);
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_array()) {
                ?>

                        <li><input type="checkbox" class="locations" value="<?php echo $row['Location']; ?>"><?php echo $row['Location']; ?> </li>

                <?php
                    }
                }
                ?>
            </ul>
        </div>
        <br>
        <label for="des" style="padding-top:10px;"><b>Description :</b></label>
        <br>
        <textarea id="desTxt" rows="4" cols="35" placeholder="Enter Description here..." required class="form-control"></textarea>
<br>
        <label for="Title" style="padding-top:10px;"><b>Price :</b></label>
        <br>
        <input type="text" class="form-control" placeholder="Enter Price" name="priceTxt" id="priceTxt" required>
        <br>
        <label for="Title" style="padding-top:10px;"><b>Stock :</b></label>
        <br>
        <input type="text" class="form-control" placeholder="Enter Stock" name="stockTxt" id="stockTxt" required>
        <br>

        <label for="img" style="padding-top:10px;"><b>Picture 1</b></label>
        <input type="file" id="imgUpload" name="imgUpload" required>
        <div class="ImageError"></div>

        <hr>
        <p><input type="checkbox" required> By creating an account you agree to our <a href="#">Terms & Privacy</a>.</p>
        <br>


        <div class="row" id="msg" style="padding-left: 20px; color: red;"></div>
        <button type="submit" id="registerbtn" class="registerbtn">Submit Product</button>
    </div>
</form>


<?php require_once('Includes/footer.php'); ?>