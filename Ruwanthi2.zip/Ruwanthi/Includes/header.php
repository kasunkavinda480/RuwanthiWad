<!doctype html>
<html>

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title> ShopUz | E-commerce Website </title>
	<link rel="stylesheet" href="custom/css/style.css">
	<link rel="preconnect" href="https://fonts.gstatic.com">
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700&display=swap"
		rel="stylesheet">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	
	<script src="assets/js/jquery.min.js"></script>

	<!-- DataTables -->
    <link rel="stylesheet" href="assets/plugins/datatables/jquery.dataTables.min.css">

</head>

<body>
	<div class="header">

		<div class="container">
			<div class="navbar">
				<div class="logo">
					<a href="Homepage.html"><img src="Images/logo.png" width="125px"></a>
				</div>
				<nav>
					<ul id="MenuItems">
						<li><a href="index.php">Homes</a> </li>
						<li><a href="products.php">products</a></li>
						<li><a href="about.php">About</a></li>
						<li><a href="contact.php">Contact</a></li>
						<?php 
						if (isset($_SESSION['userId'])) {
							echo ('<li><a href="account.php">Account</a></li>');
							echo ('<li><a onclick="logoutFunc()">LogOut</a></li>');
						}else{
							echo ('<li><a href="register.php">Login</a></li>');
						}
						
						?>
						
					</ul>
				</nav>
				<a href="cart.php"><img src="Images/cart1.png" width="30px" height="30px"></a>
				<img src="Images/menu.png" class="menu-icon" onClick="menutoggle()">
			</div>
			<div class="row">
				<div class="col-2">
					<h1>Give Your Lifestyle<br>A New Style!</h1>
					<p> paragraph mona hari danna one methanta </p>
					<a href="" class="btn">Explore Now &#8594;</a>
				</div>
				<div class="col-2">
					<img src="Images/beautiful-woman-wearing-nice-clothes-260nw-398760673.webp">
				</div>
			</div>
		</div>
	</div>
