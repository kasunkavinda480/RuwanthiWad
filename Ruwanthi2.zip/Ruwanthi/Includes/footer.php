	<!------------footer------------>

	<div class="footer">
		<div class="container">
			<div class="row">
				<div class="footer-col-1">
					<h3>Download our App</h3>
					<p>Download App for Android and ISo Mobile Phone</p>
					<div class="app-logo">
						<img src="Images/play-store.png">
						<img src="Images/app-store.png">
					</div>
				</div>
				<div class="footer-col-2">
					<img src="Images/logow.png">
					<p>our purpose is always give best products to out valuble customers.</p>
				</div>
				<div class="footer-col-3">
					<h3>Useful Links</h3>
					<ul>
						<li>Coupons</li>
						<li>Blog Post</li>
						<li>Return Policy</li>
					</ul>
				</div>
				<div class="footer-col-3">
					<h3>Information</h3>
					<ul>
						<li>About Us</li>
						<li>Contact </li>
						<li>Terms and Conditions</li>
					</ul>
				</div>
			</div>
			<hr>
		</div>
	</div>
	<!--------JS for toggle menu------------>
	<script>
		var MenuItems = document.getElementById("MenuItems");
		MenuItems.style.maxHeight = "0px";

		function menutoggle() {
			if (MenuItems.style.maxHeight == "0px") {
				MenuItems.style.maxHeight = "200px";
			} else {
				MenuItems.style.maxHeight = "0px";
			}

		}
	</script>
	<script src="./custom/js/main.js"></script>
	<!-- DataTables -->
	<script src="assets/plugins/datatables/jquery.dataTables.min.js"></script>
	</body>

	</html>