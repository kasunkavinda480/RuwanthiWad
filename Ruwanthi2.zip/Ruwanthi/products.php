<?php require_once('./php_Action/core.php');
if (isset($_GET["action"])) {

	$query = "SELECT * FROM `ads`";
	if (isset($_GET["search"])) {
		$search = $_GET["search"];

		$query = "SELECT * FROM `ads` WHERE `title` like '%" . $search . "%'";
	}
	if (isset($_GET["category"])) {
		if ($_GET["category"] != "") {
			$category_filter = $_GET["category"];
			$query .= "
		 AND category_id IN('" . $category_filter . "')
		";
		}
	}
	if (isset($_GET["location"])) {
		if ($_GET["location"] != "") {
			$location_filter = $_GET["location"];
			$query .= "
		 AND `location` lIKE ('%" . $location_filter . "%')
		";
		}
	}
	$query .= "ORDER BY modified_date DESC ";
	//pagination1
	$record_per_page = 20;
	$page = '';

	if (isset($_GET["page"])) {
		$page = $_GET["page"];
	} else {
		$page = 1;
	}

	$start_from = ($page - 1) * $record_per_page;
	$pagec = $query;
	$query .= "LIMIT $start_from, $record_per_page;";

	$output = '';
} else {
	$query = "SELECT * FROM `ads` WHERE 1 ";
	$query .= "ORDER BY modified_date DESC ";
	$record_per_page = 20;
	$page = '';

	if (isset($_GET["page"])) {
		$page = $_GET["page"];
	} else {
		$page = 1;
	}

	$start_from = ($page - 1) * $record_per_page;
	$pagec = $query;
	$query .= "LIMIT $start_from, $record_per_page;";

	$output = '';
}

require_once('Includes/header.php'); ?>
<!-----------All products------------->
<div class="small-container">
	<div class="row row-2">
		<h2> All Products</h2>
		<select>
			<option>Default Shorting</option>
			<option>Short by price</option>
			<option>Short by popularity</option>
			<option>Short by rating</option>
			<option>Short by sale</option>
		</select>

	</div>

	
	<?php
	if (isset($_GET["search"])) {
		$curcate = $_GET["category"];
	} else {
		$curcate = "";
	}
	//this for the page
	if (isset($_GET["page"])) {
		$currentPage = $_GET["page"];
	} else {
		$currentPage = 1;
	}

	//this fot the location
	if (isset($_GET["location"])) {
		$Nlocation = $_GET["location"];
	} else {
		$Nlocation = "";
	}

	//this for the sraech
	if (isset($_GET["search"])) {
		$nsearch = $_GET["search"];
	} else {
		$nsearch = "";
	}

	$result = $connect->query($query);
	$x = 1;
	$y = 1;
	$output = '';
	if ($result->num_rows > 0) {
		while ($row = $result->fetch_array()) {

			$imgloc = "php_Action/user/" . $row['img'];
			$newdate = $row['modified_date'];
			
			$title = substr($row["title"], 0, 80);
			if ($x == 1) {
				$output .= '<div class="row">';
			}
			++$x;
			++$y;
			$output .= '<div class="col-4">
			<a href="viewAd.php?aid='.$row['id'].'">
			<img src="' . $imgloc . '" class="productImage">
			</a>
				<h4>' . $title . '</h4>
					<div class="rating">
					<i class="fa fa-star" ></i>
					<i class="fa fa-star" ></i>
					<i class="fa fa-star" ></i>
					<i class="fa fa-star" ></i>
					<i class="fa fa-star-o" ></i>
					</div>
				<p>Rs.' . $row["price"] . '.00</p>
				
			</div>';
			if ($x == 5) {
				$output .= '</div>';
				$x = 1;
			}
		}
		if($y%4 != 0){
			//$ss = $y%4;
			$output .= '</div>';
			//echo('<script>alert('.$ss.')</script>');
		}
		echo($output);

		//pagination2	
		$output1 = "";
		$output1 .= '<div align="center" style="padding-top: 14px;">';
		$result1 = $connect->query($pagec);
		$total_records = mysqli_num_rows($result1);
		$total_pages = ceil($total_records / $record_per_page);
		//100/20 = 5
		//next page 
		if (isset($_GET["page"])) {
			//api page ekaka nam inne
			$n = $_GET["page"];
			$b = $_GET["page"];

			$b--;
			if ($b != 0) {
				$output1 .= "<span class='page-btn' style='cursor:pointer; padding:6px; border:3px solid #ccc;' id='" . $b . "'>Back</span>";
			}
			$n++;
			if ($total_pages >= $n) {
				$output1 .= "<span class='page-btn' style='cursor:pointer; padding:6px; border:3px solid #ccc;' id='" . $n . "'>Next</span>";
			}


			$output1 .= ' <input type="hidden" name="action" id="pactionTxt" value="1">
                            
                            <input type="hidden" name="category" id="pcategoryTxt" value="' . $curcate . '">
                            <input type="hidden" name="search" id="psearchTxt" value="' . $nsearch . '">
                            <input type="hidden" name="location" id="plocationTxt" value="' . $Nlocation . '">';
		} else {

			//api page ekaka naththam
			//<input type="hidden" name="page" id="ppageTxt" value="1">
			$output1 .= "<span class='page-btn' style='cursor:pointer; padding:6px; border:3px solid #ccc;' id='2'>Next</span>";

			$output1 .= ' <input type="hidden" name="action" id="pactionTxt" value="1">
                            
                            <input type="hidden" name="category" id="pcategoryTxt" value="' . $curcate . '">
                            <input type="hidden" name="search" id="psearchTxt" value="' . $nsearch . '">
                            <input type="hidden" name="location" id="plocationTxt" value="' . $Nlocation . '">';
		}
		for ($i = 1; $i <= $total_pages; $i++) {


			/*$output .= '<form action="" method="GET">
                            <input type="hidden" name="action" id="pactionTxt" value="1">
                            <input type="hidden" name="page" id="ppageTxt" value="' . $i . '">
                            <input type="hidden" name="category" id="pcategoryTxt" value="' . $curcate . '">
                            <input type="hidden" name="search" id="psearchTxt" value="' . $nsearch . '">
                            <input type="hidden" name="location" id="plocationTxt" value="' . $Nlocation . '">
                            <button type="submit" name="submitBtn" id="submitBtn" style="padding:6px; border:3px solid #ccc;">' . $i . '</button> 
                            </form>'; */
		}
		$output1 .= '</div><br />';

		$response =  $output1;
	} else {
		$response = '<div align="center" style="padding-top:30%";><h4>Please Refresh the Page</h4></br> 
                        <div align="center"><button type="button" class="btn btn-primary" onClick="window.location.reload();">Refresh</button></div></div>';
	}
	echo ($response);

	?>

	

	
</div>
<script src="./custom/js/index.js"></script>
<?php require_once('Includes/footer.php'); ?>