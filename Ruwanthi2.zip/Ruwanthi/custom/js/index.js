$(document).ready(function () {
   
    function filter_data(page) {
        var category = $('#pcategoryTxt').val();
        var location = $('#plocationTxt').val();
        var search = $('#psearchTxt').val();
        window.location.href = 'products.php?action=1&page='+page+'&category='+category+'&location='+location+'&search='+search;

    }
    $(document).on('click', '.page-btn', function () {
        var page = $(this).attr("id");
        filter_data(page)
    });
    
});