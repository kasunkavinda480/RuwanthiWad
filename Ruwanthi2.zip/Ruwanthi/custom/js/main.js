function logoutFunc() {
    var action="logout";
    $.ajax({
        url: "php_Action/logout.php",
        method: "POST",
        data: {
            action: action,
        },
        success: function (data) {
            $('.account_div').html(data);
            setTimeout(function () {
                window.location.href = "index.php";
            }, 1000);

        }
    });

}