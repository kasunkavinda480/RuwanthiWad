$(document).ready(function () {

    $("#postAdForm").unbind('submit').bind('submit', function () {

        event.preventDefault();
        

        var action = 'fetch_data';
        var title = $("#titleTxt").val();
        var phone = $("#phoneTxt").val();
        var category = $("#categoryTxt").val();
        var locations = get_filter('locations');
        var des = $("#desTxt").val();


        var stockTxt = $("#stockTxt").val();
        var priceTxt = $("#priceTxt").val();
       

        var status = UploadImage();



        phone = phone.substring(1);

        function get_filter(class_name) {
            var filter = [];
            $('.' + class_name + ':checked').each(function () {
                filter.push($(this).val());
            });
            return filter;
        }

        function UploadImage() {
            
            var error_images = '';
            var form_data = new FormData();
            var files = $('#imgUpload')[0].files;
            if (files.length > 1) {
                error_images += 'You can not select more than 1 file';
            } else {
                for (var i = 0; i < files.length; i++) {
                    var name = document.getElementById("imgUpload").files[i].name;
                    var ext = name.split('.').pop().toLowerCase();
                    if (jQuery.inArray(ext, ['gif', 'png', 'jpg', 'jpeg']) == -1) {
                        error_images += '<p>Invalid File Type</p>';
                    }
                    var oFReader = new FileReader();
                    oFReader.readAsDataURL(document.getElementById("imgUpload").files[i]);
                    var f = document.getElementById("imgUpload").files[i];
                    var fsize = f.size || f.fileSize;
                    if (fsize > 2000000) {
                        error_images += '<p>File Size Limit Exceeded</p>';
                    } else {
                        form_data.append("file[]", document.getElementById('imgUpload').files[i]);
                    }
                }
            }
            return error_images;
        }
        var form_data = new FormData();
        form_data.append("file[]", document.getElementById('imgUpload').files[0]);
        form_data.append("action", action);
        form_data.append("title", title);
        form_data.append("phone", phone);
        form_data.append("category", category);
        form_data.append("locations[]", locations);
        form_data.append("des", des);

        form_data.append("stockTxt", stockTxt);
        form_data.append("priceTxt", priceTxt);
       


        if (status == '') {
            //$("#registerbtn").button('loading');
            
            $.ajax({
                url: "php_Action/user/postproduct.php",
                method: "POST",
                data: form_data,
                contentType: false,
                cache: false,
                processData: false,
                success: function (data) {
                    $('#msg').html("Success");
                    //window.location.href("viewAccount.php");
                    //$("#registerbtn").button('reset');
                    //gotoviewAcccount();
                    alert(data);
                    //location.reload();
                },
                error: function (data) {
                    alert("Error! Please Try Again..." + data);
                    
                }
            });
        }
        else {
            $('#msg').html(status);
            
        }

    });

});

function gotoviewAcccount() {
    window.location.href='viewAccount.php'
}
