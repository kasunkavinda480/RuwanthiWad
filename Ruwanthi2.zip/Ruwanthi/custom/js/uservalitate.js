$(document).ready(function () {
    //alert('working');
    $('#RegForm').unbind('submit').bind('submit', function () {
        var UserName = $("#UserNameTxt").val();
        var password = $("#passwordTxt").val();
        var compass = $("#CompassTxt").val();
        var Email = $("#EmailTxt").val();

        if (UserName == "") {
			$("#UserNameTxt").after('<p class="text-danger"> Name field is required</p>');
			$('#UserNameTxt').closest('.form-group').addClass('has-error');
		} else {
			// remov error text field
			$("#UserNameTxt").find('.text-danger').remove();
			// success out for form 
			$("#UserNameTxt").closest('.form-group').addClass('has-success');
		}
		if (password == "") {
			$("#passwordTxt").after('<p class="text-danger">Passsword field is required</p>');

			$('#passwordTxt').closest('.form-group').addClass('has-error');
		} else {
			// remov error text field
			$("#passwordTxt").find('.text-danger').remove();
			// success out for form 
			$("#passwordTxt").closest('.form-group').addClass('has-success');
		}
		if (compass == "") {
			$("#CompassTxt").after('<p class="text-danger"> Confirm password field is required</p>');
			$('#CompassTxt').closest('.form-group').addClass('has-error');
		} else {
			// remov error text field
			$("#CompassTxt").find('.text-danger').remove();
			// success out for form 
			$("#CompassTxt").closest('.form-group').addClass('has-success');
		}
		if (Email == "") {
			$("#EmailTxt").after('<p class="text-danger"> Email field is required</p>');
			$('#EmailTxt').closest('.form-group').addClass('has-error');
		} else {
			// remov error text field
			$("#EmailTxt").find('.text-danger').remove();
			// success out for form 
			$("#EmailTxt").closest('.form-group').addClass('has-success');
		}
		if (password != compass) {
			$("#CompassTxt").after('<p class="text-danger"> Password not equal to Confirm Password</p>');
			$('#CompassTxt').closest('.form-group').addClass('has-error');
		} else {
			// remov error text field
			$("#CompassTxt").find('.text-danger').remove();
			// success out for form 
			$("#CompassTxt").closest('.form-group').addClass('has-success');
		}

        //alert('Email');
        if (Email && UserName && password && compass && (password == compass)) {

			var form_data = new FormData();
			form_data.append("UserNameTxt", UserName);
			form_data.append("passwordTxt", password);
			form_data.append("CompassTxt", compass);
			form_data.append("EmailTxt", Email);
			$.ajax({
                url: "./php_Action/user/regfrm.php",
                method: "POST",
                data: form_data,
				dataType: 'json',
                contentType: false,
                cache: false,
                processData: false,
                success: function (data) {
                    $('#msg').html("Success");
                    //window.location.href("viewAccount.php");
                    //$("#registerbtn").button('reset');
                    //gotoviewAcccount();
                    
					if(data.success ==true){
						alert(data.messages);
						location.reload();
					}else{
						alert(data.messages);
					}
                    //location.reload();
                },
                error: function (data) {
                    alert("Error! Please Try Again..." + data);

                }
            });
			

        }

        return false;
    });

    $("#logfrm").unbind('submit').bind('submit', function() {

		// remove the error 
		$('.text-danger').remove();
		
        //This part for the getting value if empty or Not
        var UserName  = $("#username").val();
        var password = $("#password").val();
        if(UserName == "") {
			$("#username").after('<p class="text-danger"> Email field is required</p>');
			$('#username').closest('.form-group').addClass('has-error');
		} else {
			// remov error text field
			$("#username").find('.text-danger').remove();
			// success out for form 
			$("#username").closest('.form-group').addClass('has-success');	  	
		}

		if(password == "") {
			$("#password").after('<p class="text-danger">Passsword field is required</p>');

			$('#password').closest('.form-group').addClass('has-error');
		} else {
			// remov error text field
			$("#password").find('.text-danger').remove();
			// success out for form 
			$("#password").closest('.form-group').addClass('has-success');	  	
		}

        if(UserName && password) {
			var form_data = new FormData();

			form_data.append("username", UserName);
			form_data.append("password", password);	
            $.ajax({
                url: "./php_Action/login/login.php",
                method: "POST",
                data: form_data,
				dataType: 'json',
                contentType: false,
                cache: false,
                processData: false,
                success: function (data) {
                    $('#msg').html("Success");
                    //window.location.href("viewAccount.php");
                    //$("#registerbtn").button('reset');
                    //gotoviewAcccount();
                    if(data.success ==true){
						alert(data.messages);
						location.reload();
					}else{
						alert(data.messages);
					}
                },
                error: function (data) {
                    alert("Error! Please Try Again..." + data);

                }
            });
        } // if
        return false;
    });
});