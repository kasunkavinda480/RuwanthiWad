$(document).ready(function () {
    var id = $("#aid").val();
   //alert(id);
    var action = 'load';
    /*$('.chkbox:checked').each(function () {
        $(".chkbox").prop("checked", false);
    });*/
    $.ajax({
        url: "php_Action/user/viewContent.php",
        method: "POST",
        data: {
            id: id,
        },
        dataType: 'json',
        success: function (response) {
            //$('.add_div').html(data);
            relatedAds();
            
            var len = response.length;
            if (len > 0) {
                var title = response[0]['title'];
                var des = response[0]['des'];
                var phone = response[0]['phone'];
                var location = response[0]['location'];
                var imageloc = response[0]['ImageLoc'];
                var newdate = response[0]['AddDate'];
                var price = response[0]['price'];
                var stock = response[0]['stock'];
                //document.getElementById('AddTitleTXt').value = title;
                $('#AddTitleTXt').html(title);
                $('#desctiptionTxt').html(des);
                $('#sellerPhoneNumberaa').html('<a href="tel:0' + phone + '"> 0' + phone + '</a>');
                $('.addDistrict').html(location);

                $('#priceTXt').html('Rs '+price+'.00');
                $('#stockTxt').html(stock);
                
                var mainfrm = '<form action="viewAd.php?aid='+id+'&idTxt='+id+'" method="POST">'
                +'<input type="hidden" name="idTxt" value="'+id+'">'
                +'<input type="hidden" name="nameTxt" value="'+title+'">'
                +'<input type="hidden" name="ImageTxt" value="'+imageloc+'">'
                +'<input type="hidden" name="PriceTxt" value="'+price+'">'
                +'<input type="number" name="QtyTxt" value="1">'
                +'<input type="submit" name="SubMintBtn" id="SubMintBtn" class="btn" value="Add to cart">'
                +'</form>';
                //this for the form data display
                $('#mainfrmcart').html(mainfrm);

                $('#addTimeTxt').html(newdate);
                //alert(imageloc);

                $('#mainAddImage').html('<img src="' + imageloc + '">');

            }
        }
    }); 
});

function relatedAds() {
    $.ajax({
        url: "php_Action/user/relatedAds.php",
        method: "POST",

        success: function (response) {

            $('#loadrelatedProDiv').html(response);

        }
    });
}
