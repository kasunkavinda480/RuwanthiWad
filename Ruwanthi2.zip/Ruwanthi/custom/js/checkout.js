$(document).ready(function () {
    $("#Checkoutfrm").unbind('submit').bind('submit', function () {
        var idtxt = $("#idTxt").val();
        var usernameTxt = $("#usernameTxt").val();
        var AddressTxt = $("#AddressTxt").val();
        var NetAmountTxt = $("#NetAmountTxt").val();

        if(AddressTxt == "") {
			$("#AddressTxt").after('<p class="text-danger">Address field is required</p>');

			$('#AddressTxt').closest('.form-group').addClass('has-error');
		} else {
			// remov error text field
			$("#AddressTxt").find('.text-danger').remove();
			// success out for form 
			$("#AddressTxt").closest('.form-group').addClass('has-success');	  	
		}

        if (idtxt && usernameTxt && AddressTxt && NetAmountTxt) {
                //alert(idtxt);
            var form_data = new FormData();
            form_data.append("idTxt", idTxt);
            form_data.append("usernameTxt", usernameTxt);
            form_data.append("AddressTxt", AddressTxt);
            form_data.append("NetAmountTxt", NetAmountTxt);
            $.ajax({
                url: "php_Action/order/completeorder.php",
                method: "POST",
                data: form_data,
                contentType: false,
                cache: false,
                processData: false,
                success: function (data) {
                    $('#msg').html("Success");
                    //window.location.href("viewAccount.php");
                    //$("#registerbtn").button('reset');
                    //gotoviewAcccount();
                    alert(data);
                    //location.reload();
                },
                error: function (data) {
                    alert("Error! Please Try Again..." + data);

                }
            });
        }
        return false;


    });
});