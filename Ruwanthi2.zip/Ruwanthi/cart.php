<?php
require_once('./php_Action/core.php');
if(isloggin() == false){
    header('location: register.php');
}
require_once('Includes/header.php'); ?>


    <!---------cart item details---------->	
	
	<div class="small-container cart-page">
		<table>
			<tr>
				<th>Product</th>
				<th>Quantity</th>
				<th>Subtotal</th> 
			</tr>

            <?php
    
    if(!empty($_SESSION['shopping_cart'])) {
        foreach($_SESSION['shopping_cart'] as $keys => $values){


            $id = $values['itm_id'];
            $name = $values['imt_name'];
            $image = $values['itm_image'];
            $price = $values['itm_price'];
            $qty = $values['itm_qty'];
            ?>
            
            <tr>
				<td>
					<div class="cart-info">
                    <img src="<?php echo $image ?>" alt="" width="75px" height="75px">
						<div>
							<p><?php echo $name ?></p>
							<small>price <?php echo $price ?>.00</small>
							<br>
							<a href="">Remove</a>
						</div>
					</div>
				</td>
				<td><input type="text" name="QtyTxt" id="QtyTxt" value="<?php echo $qty ?>"></td>
				<td>Rs <?php echo $price ?>.00</td>
			</tr>
            
            <?php
        }
    }else{
        echo 'cart is empty';
    }
    
    ?>
			
			<tfoot>
                <tr>
                <a href="checkout.php" class="btn">CheckOut &#8594;</a>
                </tr>
            </tfoot>
		</table>
	</div>

    <!--------JS for toggle menu------------>
	<script>
		var MenuItems = document.getElementById("MenuItems");
		MenuItems.style.maxHeight = "0px";
		
		function menutoggle(){
			if(MenuItems.style.maxHeight == "0px")
				{
					MenuItems.style.maxHeight = "200px";
				}
			else
			    {
					MenuItems.style.maxHeight = "0px";	
				}
			
		}
	</script>
<?php require_once('Includes/footer.php'); ?>