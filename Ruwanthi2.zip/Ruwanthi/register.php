<?php
require_once('./php_Action/core.php');
if(isloggin() == true){
    header('location: account.php');
}
require_once('Includes/header.php'); ?>

<!----------account page------------->

<div class="account-page">
    <div class="container">
        <div class="row">
            <div class="col-2">
                <img src="Images/beautiful-woman-wearing-nice-clothes-260nw-398760673.webp">
            </div>
            <div class="col-2">
                <div class="form-container">
                    <div class="form-button">
                        <span onclick="login()">Login</span>
                        <span onclick="register()">Register</span>
                        <hr id="Indicator">
                    </div>

                    <form class="form" id="logfrm" method="POST" action="#" enctype="multipart/form-data">
                        <input type="text" placeholder="Username" name="username" id="username">
                        <input type="password" placeholder="Password" name="password" id="password">
                        <button type="submit" class="btn">Login</button>
                        
                    </form>

                    <form class="form1" id="RegForm" method="POST" action="./php_Action/user/regfrm.php" enctype="multipart/form-data">
                        <input type="text" placeholder="Full Name" name="UserNameTxt" id="UserNameTxt">
                        <!--<input type="text" placeholder="Address" >
                        <input type="text" placeholder="Contact Number">-->
                        <input type="email" placeholder="Email" name="EmailTxt" id="EmailTxt">
                        <input type="password" placeholder="Password" name="passwordTxt" id="passwordTxt">
                        <input type="password" placeholder="Confirm password" id="CompassTxt">
                        
                        <button type="submit" class="btn" onclick="" id="regfrmBtn">Register</button>
                    </form>

                </div>
            </div>
        </div>
    </div>
</div>

<script src="./custom/js/uservalitate.js"></script>
<script>
    var LoginForm = document.getElementById("LoginForm");
    var RefForm = document.getElementById("RegForm");
    var Indicator = document.getElementById("Indicator");

    function register() {
        RegForm.style.transform = "translateX(0px)"
        LoginForm.style.transform = "translateX(0px)"
        Indicator.style.transform = "translateX(150px)"

    }

    function login() {
        RegForm.style.transform = "translateX(300px)"
        LoginForm.style.transform = "translateX(300px)"
        Indicator.style.transform = "translateX(50px)"
    }
</script>

<?php require_once('Includes/footer.php'); ?>