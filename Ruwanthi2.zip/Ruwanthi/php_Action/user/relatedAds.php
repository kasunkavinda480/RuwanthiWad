<?php
require_once '../config.php';
include('../function.php');

$query = "SELECT * FROM `ads` WHERE 1 ORDER BY modified_date DESC LIMIT 4";


$output = '';
$result = $connect->query($query);
$x = 1;
if ($result->num_rows > 0) {
    while ($row = $result->fetch_array()) {

        $imgloc = "php_Action/user/" . $row['img'];
        $newdate = $row['modified_date'];
        
        $title = substr($row["title"], 0, 80);
        if ($x == 1) {
            $output .= '<div class="row">';
        }
        ++$x;
        $output .= '<div class="col-4">
        <a href="viewAd.php?aid='.$row['id'].'">
        <img src="' . $imgloc . '" class="relatesIemcls">
            <h4>' . $title . '</h4>
                <div class="rating">
                <i class="fa fa-star" ></i>
                <i class="fa fa-star" ></i>
                <i class="fa fa-star" ></i>
                <i class="fa fa-star" ></i>
                <i class="fa fa-star-o" ></i>
                </div>
            <p>Rs.' . $row["price"] . '.00</p>
            </a>
        </div>';
        if ($x == 5) {
            $output .= '</div>';
            
        }
    }
}
$output .= '</div>';
echo $output;
