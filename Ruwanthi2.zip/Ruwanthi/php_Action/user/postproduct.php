<?php
require_once '../core.php';
require_once '../function.php';

if (isset($_POST["action"])) {

    $userId = $_SESSION['userId'];
    
    $phone = mysqli_real_escape_string($connect, $_POST['phone']);
    $title = mysqli_real_escape_string($connect, $_POST['title']);
    $category = mysqli_real_escape_string($connect, $_POST['category']);
    $des = mysqli_real_escape_string($connect, $_POST['des']);

    $priceTxt = mysqli_real_escape_string($connect, $_POST['priceTxt']);
    $stockTxt = mysqli_real_escape_string($connect, $_POST['stockTxt']);
    date_default_timezone_set("Asia/Colombo");
    $date = date('Y-m-d H:i:s');

    //this for the trans details
    

    $locations_filter = "-";
    if (isset($_POST["locations"])) {
        $locations_filter = implode(",", $_POST["locations"]);
    }

    $file_name = $_FILES["file"]["name"][0];
    $tmp_name = $_FILES["file"]['tmp_name'][0];

    $file = explode(".", $_FILES["file"]["name"][0]);
    $extension = end($file);
    $name = rand(100, 10000) . '.' . $extension;
    $location = 'upload/'  . $name;

    if (move_uploaded_file($tmp_name, $location)) {

        //watermark add
        $watermark_image = imagecreatefrompng('LogoFinal.png');

        if ($extension == 'jpg' || $extension == 'jpeg') {
            $image = imagecreatefromjpeg($location);
        }

        if ($extension == 'png') {
            $image = imagecreatefrompng($location);
        }

        $margin_right = 10;
        $margin_bottom = 10;

        $watermark_image_width = imagesx($watermark_image);
        $watermark_image_height = imagesy($watermark_image);

        imagecopy($image, $watermark_image, imagesx($image) - $watermark_image_width - $margin_right, imagesy($image) - $watermark_image_height - $margin_bottom, 0, 0, $watermark_image_width, $watermark_image_height);

        imagejpeg($image, $location);
        imagedestroy($image);
    }

    $query = "INSERT INTO `ads`(`user_id`, `category_id`, `title`, `des`, `phone`, `location`, `img`, `post_date`, `modified_date`, `status`,`price`,`stock`) VALUES ('$userId','$category','$title','$des','$phone','$locations_filter','$location','$date','$date','$state','$priceTxt','$stockTxt');";

    $result = $connect->query($query);

    if (($result) === TRUE) {
        $valid = "Success";
    } else {
        $valid = "Error";
    }

    echo $valid;
}
