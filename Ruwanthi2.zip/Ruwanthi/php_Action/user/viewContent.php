<?php
require_once '../config.php';
require_once '../function.php';
if ($_POST['id']) {

    $id = $_POST['id'];
    $users_arr = array();
    $output = "Something went wrong!!";
    $query1 = "SELECT * FROM `ads` WHERE `id`='$id'";

    $result = $connect->query($query1);
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_array()) {
            $title = $row['title'];
            $des = $row['des'];
            $phone = $row['phone'];
            $location = $row['location'];
            $imgloc = "php_Action/user/" . $row['img'];
            $newdate =$row['modified_date'];
            /*date_default_timezone_set("Asia/Colombo");
            $date = date('Y-m-d H:i:s');

            $date1 = $row['post_date'];;
            $date2 = $date;
            $timestamp1 = strtotime($date1);
            $timestamp2 = strtotime($date2);
            $hour = abs($timestamp2 - $timestamp1) / (60 * 60);*/
            $price = $row['price'];
            $stock = $row['stock'];

            $users_arr[] = array("id" => $id, "title" => $title,"des" => nl2br($des), "phone" =>$phone, "location" =>$location,"ImageLoc" =>$imgloc,"AddDate"=> $newdate,"price"=>$price,"stock"=>$stock);
        }
    }
    echo json_encode($users_arr);
} else {
    header('Location:index.php');
}

