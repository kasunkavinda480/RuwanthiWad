<?php
include('../core.php');
require_once '../function.php';
$output = '';

if(isloggin() == false){
    if ($_POST) {
        $userName = mysqli_real_escape_string($connect, $_POST['UserNameTxt']);
        $email = mysqli_real_escape_string($connect, $_POST['EmailTxt']);
        $planepassword = mysqli_real_escape_string($connect, $_POST['passwordTxt']);
    
        $chksql = $connect->query("SELECT * FROM users WHERE Email = '$email'");
        if ($chksql->num_rows == 0) {
    
            //this part for the random no gen
            $no = rand(10000, 1000000);
            $dataTime = date("Y-m-d");
            //$password = md5($password);
            $password = convert_string('encrypt', $planepassword);
            
    
            $sql = $connect->query("INSERT INTO `users` (`id`, `Name`, `Email`, `Password`, `Type`, `Activate`, `ActiveCode`, `RegDate`) VALUES (NULL, '$userName', '$email', '$password', 'Normal', 'active', '$no', '$dataTime');");
            if ($sql === true) {
                $mainSql = "SELECT * FROM users WHERE Email = '$email' AND Password = '$password'";
                    $mainResult = $connect->query($mainSql);
    
                    if ($mainResult->num_rows == 1) {
                        $value = $mainResult->fetch_assoc();
                        //getting user id
                        $user_id = $value['id'];
                        //type And Activation
                        $type = $value['Type'];
                        $activate = $value['Activate'];
                        //Add to session
    
                        $_SESSION['userId'] = $user_id;
                        $_SESSION['Type'] = $type;
                        $_SESSION['Activate'] = $activate;
                        $_SESSION['Uname'] = $userName;
                        $valid['success'] = true;
                        $valid['messages'] = "Successfully Added";
    
                    } 
            }else {
                $valid['success'] = false;
                $valid['messages'] = "Error while adding the members";
            }
        }else {
            $valid['success'] = false;
            $valid['messages'] = 'This Email Allready Add In System';
        }
    }
}else {
    $valid['success'] = false;
    $valid['messages'] = 'You Are all ready Login';
}

$connect->close();
echo json_encode($valid);


