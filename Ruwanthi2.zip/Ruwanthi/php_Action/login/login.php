<?php
//dffdfdfd

//session_start();
require_once '../core.php';
require_once '../function.php';

$errors = array();

if ($_POST) {

	$email = mysqli_real_escape_string($connect, ($_POST['username']));
	$planepassword = mysqli_real_escape_string($connect, ($_POST['password']));

		$sql = "SELECT * FROM users WHERE Email = '$email'";
		$result = mysqli_query($connect, $sql);

		if (mysqli_num_rows($result) == 1) {
			//$password = md5($password);
			$password = convert_string('encrypt', $planepassword);
			// exists
			$mainSql = "SELECT * FROM users WHERE Email = '$email' AND Password = '$password'";
			$mainResult = mysqli_query($connect, $mainSql);

			if (mysqli_num_rows($mainResult) == 1) {
				$value = mysqli_fetch_assoc($mainResult);

				$user_id = $value['id'];

				//type And Activation
				$type = $value['Type'];
				$activate = $value['Activate'];
				$usname = $value['Name'];
				// set session
				$_SESSION['userId'] = $user_id;
				$_SESSION['Activate'] = $activate;
				$_SESSION['Type'] = $type;
				$_SESSION['Uname'] = $usname;
				$valid['success'] = true;

				//get the message to the activate or Not
				$valid['messages'] = 'Login Sucess';

				//header('location:../StockManage/dashboard.php');	
			} else {
				$valid['success'] = false;
				$valid['messages'] = "Password Or Email Is Not Correct";
				
			} // /else
		} else {
			$valid['messages'] = "Email doesnot exists";
			$valid['success'] = false;
		} // /else
	

	//$valid['success'] = false;
	//$valid['messages'] = "Password Or Email Is Not Correct";
} // /if $_POST

$connect->close();
echo json_encode($valid);
