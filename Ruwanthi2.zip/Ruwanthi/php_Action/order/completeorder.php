<?php
require_once '../core.php';
require_once '../function.php';

if (isset($_POST["idTxt"])) {
    $userId  =$_SESSION['userId'];
    $idTxt = mysqli_real_escape_string($connect, $_POST['idTxt']);
    $usernameTxt = mysqli_real_escape_string($connect, $_POST['usernameTxt']);
    $AddressTxt = mysqli_real_escape_string($connect, $_POST['AddressTxt']);
    $NetAmountTxt = mysqli_real_escape_string($connect, $_POST['NetAmountTxt']);
    date_default_timezone_set("Asia/Colombo");
    $date = date('Y-m-d H:i:s');


    $sqlss = $connect->query("INSERT INTO `order` (`oid`, `Users_id`, `userName`, `Address`, `NetAmount`, `odate`, `state`) VALUES (NULL, '$userId', '$usernameTxt', '$AddressTxt', '$NetAmountTxt', '$date', '0');");
    if (($sqlss) === TRUE) {
        $sql = "SELECT * FROM `order` WHERE Users_id = $userId ORDER BY oid DESC LIMIT 1";
            $result = $connect->query($sql);

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_array()) {
                    $orid = $row['oid'];
                }
            }

        if (!empty($_SESSION['shopping_cart'])) {
            foreach ($_SESSION['shopping_cart'] as $keys => $values) {

                
                $proId = $values['itm_id'];
                $productName = $values['imt_name'];
                $image = $values['itm_image'];
                $single_price = $values['itm_price'];
                $qty = $values['itm_qty'];
                $price = $qty * $single_price;
                $addItem = $connect->query("INSERT INTO `orderitems` (`idOrderItems`, `Order_oid`, `Proid`, `Image`, `Name`, `Price`, `qty`, `Amount`) VALUES (NULL, '$orid', '$proId','$image', '$productName', '$single_price', '$qty', '$price');");
            
            }
        }
        $valid = "Success";
    } else {
        $valid = "Error";
    }

    echo $valid;
}
