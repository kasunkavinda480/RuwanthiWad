<?php 
require_once './core.php';
if (isset($_POST["action"])) {

    $valid = "";
    session_destroy();

    unset($_SESSION['userId']);
    unset($_SESSION['Activate']);
    //unset($_SESSION['user_type']);

    
    //
    $valid = "Success";


    echo $valid;
}
