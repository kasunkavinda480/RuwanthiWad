<?php 
session_start();
include('config.php');

function isloggin() {
    if(isset($_SESSION['userId']) && ($_SESSION['Activate'] == "active")){
        return true;
    }else{
        return false;
    }
}


?>