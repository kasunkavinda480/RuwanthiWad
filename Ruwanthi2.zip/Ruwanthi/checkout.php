<?php require_once('./php_Action/core.php');
if(isloggin() != true){
    header('location: register.php');
}
require_once('Includes/header.php'); ?>
<style>

input[type=text], select, textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  resize: vertical;
}
</style>
<div class="small-container cart-page">
    <table>
        <tr>
            <th>Product</th>
            <th>Quantity</th>
            <th>Subtotal</th>
        </tr>

        <?php

        if (!empty($_SESSION['shopping_cart'])) {
            $tot = 0;
            foreach ($_SESSION['shopping_cart'] as $keys => $values) {
               

                $id = $values['itm_id'];
                $name = $values['imt_name'];
                $image = $values['itm_image'];
                $price = $values['itm_price'];
                $qty = $values['itm_qty'];
                $tot += $qty * $price;
        ?>

                <tr>
                    <td>
                        <div class="cart-info">
                            <img src="<?php echo $image ?>" alt="" width="75px" height="75px">
                            <div>
                                <p><?php echo $name ?></p>
                                <small>price <?php echo $price ?>.00</small>
                                <br>
                                <a href="">Remove</a>
                            </div>
                        </div>
                    </td>
                    <td><input type="text" name="QtyTxt" id="QtyTxt" value="<?php echo $qty ?>"></td>
                    <td>Rs <?php echo $price ?>.00</td>
                </tr>

        <?php
            }
        } else {
            $tot = 0;
            echo 'cart is empty';
        }

        ?>

        <tfoot>
            <tr>
                <a href="checkout.php" class="btn">CheckOut &#8594;</a>
            </tr>
        </tfoot>
    </table>
</div>
<br><br>
<div class="mainchkout">
    <form action="#" method="POST" id="Checkoutfrm">
        <label for="">User Id :</label>
        <input type="text" class="mainchktxt" name="idTxt" id="idTxt" value="<?php echo ($_SESSION['userId']) ?>" readonly>
        <br>
        <label for="">UserName :</label>
        <input type="text" class="mainchktxt" name="usernameTxt" id="usernameTxt" value="<?php echo ($_SESSION['Uname']) ?>" readonly>
        <br>
        <label for="">Address :</label>
        <input type="text" class="mainchktxt" name="AddressTxt" id="AddressTxt" value="">
        <br>
        <label for="">Net Amount :</label>
        <input type="text" class="mainchktxt" name="NetAmountTxt" id="NetAmountTxt" value="<?php echo ($tot) ?>" readonly>
        <br>
        <br>
        <input type="submit" name="submitBtn" id="submitBtn" class="btn" value="Complete Order">
    </form>

</div>
<script src="./custom/js/checkout.js"></script>
<?php require_once('Includes/footer.php'); ?>